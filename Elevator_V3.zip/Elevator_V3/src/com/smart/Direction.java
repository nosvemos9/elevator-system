package com.smart;

public enum Direction {
    UP,
    DOWN,
    IDLE
}
